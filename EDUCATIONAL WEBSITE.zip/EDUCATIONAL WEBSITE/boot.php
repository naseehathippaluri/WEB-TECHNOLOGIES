
<?php
 
$conn=mysqli_connect("localhost","root","","project");
if($conn){
    echo "connected"."<br/>";
}
else
    echo "not connected"."<br/>";

 
$name=$_POST['name1'];
$password=$_POST['password'];
$email=$_POST['email'];
$phone=$_POST['phone1'];
$gender=$_POST['sex'];
$branch=$_POST['branch'];

$insert="insert into   `USER_DETAILS`(`NAME`,`EMAIL`,`PASSWORD`,`NUMBER`,`GENDER`,`BRANCH`)values(?,?,?,?,?,?)";
$stmt=mysqli_prepare($conn,$insert);
mysqli_stmt_bind_param($stmt,'ssssss',$name,$email,$password,$phone,$gender,$branch);
mysqli_stmt_execute($stmt);
?>


